class User {
  int ID = 0;
  String username = "";
  String? clinicName;
  int permission = 0;
}
