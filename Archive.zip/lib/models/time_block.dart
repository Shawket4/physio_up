class TimeBlock {
  DateTime? dateTime;
  bool? isAvailable;
  TimeBlock({
    this.dateTime,
    this.isAvailable,
  });
}
