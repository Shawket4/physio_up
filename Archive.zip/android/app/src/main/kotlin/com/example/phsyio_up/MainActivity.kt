package com.example.phsyio_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
